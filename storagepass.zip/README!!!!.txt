En:
Greetings, bro!
If you downloaded it, then you need to store your passwords in a safe place or create secure passwords.
Remember:
Do not change the program directory! Happy using
-------------------------------------------------
